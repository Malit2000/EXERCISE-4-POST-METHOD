<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $age = htmlspecialchars($_POST['age'] ?? '');
    $nickname = htmlspecialchars($_POST['nickname'] ?? '');
    $address = htmlspecialchars($_POST['address'] ?? '');
    $image_path = 'jpeg/default.png';
    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/jpeg/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $tmp_name = $_FILES['image']['tmp_name'];
        $original_name = basename($_FILES['image']['name']);
        $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($ext, $allowed)) {
            $new_name = uniqid('member_', true) . '.' . $ext;
            $destination = $upload_dir . $new_name;
            if (move_uploaded_file($tmp_name, $destination)) {
                $image_path = 'jpeg/' . $new_name;
            }
        }
    }
    $success_message = "New team member added successfully!";
}

$team_members = [
    [
        'name' => 'Christian Peralta',
        'age' => 21,
        'nickname' => 'Tan',
        'address' => 'San Pedro, Laguna',
        'image' => 'jpeg/peralta.png'
    ],
    [
        'name' => 'John Michael Malit',
        'age' => 25,
        'nickname' => 'Michael',
        'address' => 'Bayanan, Muntinlupa',
        'image' => 'jpeg/malit.png'
    ],
    [
        'name' => 'Arvin Corteza',
        'age' => 28,
        'nickname' => 'Vin',
        'address' => 'Almanza Dos, Las Piñas',
        'image' => 'jpeg/vin.png'
    ],
    [
        'name' => 'Erickson Ayag',
        'age' => 26,
        'nickname' => 'Erickson',
        'address' => 'Bayanan, Muntinlupa',
        'image' => 'jpeg/ayag.png'
    ]
];

// Add new member if POST data exists
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($name)) {
    $team_members[] = [
        'name' => $name,
        'age' => $age,
        'nickname' => $nickname,
        'address' => $address,
        'image' => $image_path // use uploaded image or default
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRREGULARS</title>
    <link rel="stylesheet" href="post.css">
</head>
<body>
    <main class="main-content">
        <div class="container">
            <h1 class="section-title">THE IRREGULARS</h1>
            
            <?php if (isset($success_message)): ?>
                <div class="success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <div class="team-grid">
                <?php foreach ($team_members as $member): ?>
                    <div class="team-member">
                        <div class="member-photo">
                            <img src="<?php echo htmlspecialchars($member['image']); ?>" alt="<?php echo htmlspecialchars($member['name']); ?>">
                        </div>
                        <h2 class="member-name"><?php echo htmlspecialchars($member['name']); ?></h2>
                        <p class="member-description">
                            Age: <?php echo htmlspecialchars($member['age']); ?><br>
                            Nickname: <?php echo htmlspecialchars($member['nickname']); ?><br>
                            Address: <?php echo htmlspecialchars($member['address']); ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <button class="toggle-form-btn" onclick="toggleForm()">Add New Member</button>
            
            <div class="form-container" id="addMemberForm">
                <div class="add-member-form">
                    <h2 class="form-title">Add New Team Member</h2>
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="name">Full Name:</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="age">Age:</label>
                            <input type="number" id="age" name="age" min="1" max="120" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="nickname">Nickname:</label>
                            <input type="text" id="nickname" name="nickname" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Address:</label>
                            <input type="text" id="address" name="address" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="image">Photo (optional):</label>
                            <input type="file" id="image" name="image" accept="image/*">
                        </div>
                        <button type="submit" class="submit-btn">Add Member</button>
                    </form>
                </div>
            </div>
        </div>
    </main>
    
    <script>
        function toggleForm() {
            const form = document.getElementById('addMemberForm');
            const btn = document.querySelector('.toggle-form-btn');
            
            if (form.classList.contains('active')) {
                form.classList.remove('active');
                btn.textContent = 'Add New Member';
            } else {
                form.classList.add('active');
                btn.textContent = 'Hide Form';
            }
        }
    </script>
</body>
</html>